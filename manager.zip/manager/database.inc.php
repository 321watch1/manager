<?php
if (!defined('ACCESS')) die('Not access');
else $databases = array(
    'db_host' => 'localhost',
    'db_username' => '',
    'db_password' => '',
    'db_name' => '',
    'is_auto' => false
);
